package dev.assisr.compasshud;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.TextColor;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public final class SavedSpotData extends SavedData {

    static final Codec<SavedSpotData> CODEC = SavedSpot.CODEC.listOf()
            .optionalFieldOf("spots", List.of())
            .xmap(SavedSpotData::new, SavedSpotData::allSpots)
            .codec();

    static final SavedDataType<SavedSpotData> TYPE = new SavedDataType<>(
            Identifier.fromNamespaceAndPath(CompassHud.MOD_ID, "saved_spots"),
            SavedSpotData::new,
            CODEC,
            DataFixTypes.SAVED_DATA_COMMAND_STORAGE
    );

    private final Map<UUID, ArrayList<SavedSpot>> byOwner = new HashMap<>();

    public SavedSpotData() {
    }

    private SavedSpotData(List<SavedSpot> spots) {
        for (SavedSpot spot : spots) {
            byOwner.computeIfAbsent(spot.owner(), id -> new ArrayList<>()).add(spot);
        }
        for (ArrayList<SavedSpot> playerSpots : byOwner.values()) {
            playerSpots.sort(Comparator.comparingLong(SavedSpot::createdAt));
        }
    }

    List<SavedSpot> spotsFor(UUID playerId) {
        ArrayList<SavedSpot> spots = byOwner.get(playerId);
        return spots == null ? List.of() : List.copyOf(spots);
    }

    SaveResult save(UUID playerId, Optional<String> label, ResourceKey<Level> dimension, BlockPos pos,
                    CompassConfig cfg) {
        ArrayList<SavedSpot> spots = byOwner.computeIfAbsent(playerId, id -> new ArrayList<>());
        for (int i = 0; i < spots.size(); i++) {
            SavedSpot existing = spots.get(i);
            if (existing.sameLocation(dimension, pos)) {
                return SaveResult.duplicate(existing, i + 1);
            }
        }

        int capacity = cfg.savedSpotMaxCount;
        if (spots.size() >= capacity) {
            return SaveResult.capacityReached(capacity);
        }

        GlyphChoice choice = chooseGlyph(spots, cfg);
        if (choice == null) {
            return SaveResult.capacityReached(capacity);
        }

        SavedSpot created = new SavedSpot(UUID.randomUUID(), playerId, cleanLabel(label), dimension,
                pos.immutable(), choice.glyph(), choice.color(), Instant.now().toEpochMilli());
        spots.add(created);
        setDirty();
        return SaveResult.created(created, spots.size());
    }

    DeleteResult delete(UUID playerId, int oneBasedIndex) {
        ArrayList<SavedSpot> spots = byOwner.get(playerId);
        if (spots == null || oneBasedIndex < 1 || oneBasedIndex > spots.size()) {
            return DeleteResult.invalid(spots == null ? 0 : spots.size());
        }

        SavedSpot removed = spots.remove(oneBasedIndex - 1);
        if (spots.isEmpty()) {
            byOwner.remove(playerId);
        }
        setDirty();
        return DeleteResult.deleted(removed);
    }

    private List<SavedSpot> allSpots() {
        return byOwner.values().stream()
                .flatMap(List::stream)
                .sorted(Comparator.comparing(SavedSpot::owner).thenComparingLong(SavedSpot::createdAt))
                .toList();
    }

    private static Optional<String> cleanLabel(Optional<String> label) {
        return label.map(String::trim).filter(s -> !s.isEmpty()).map(s -> s.length() > 64 ? s.substring(0, 64) : s);
    }

    private static GlyphChoice chooseGlyph(List<SavedSpot> existing, CompassConfig cfg) {
        Set<String> used = new HashSet<>();
        for (SavedSpot spot : existing) {
            used.add(spot.glyph());
        }
        for (int i = 0; i < cfg.savedSpotMaxCount; i++) {
            String glyph = cfg.savedSpotGlyphs[i];
            if (!used.contains(glyph)) {
                TextColor color = cfg.savedSpotColors[i % cfg.savedSpotColors.length];
                return new GlyphChoice(glyph, color);
            }
        }
        return null;
    }

    private record GlyphChoice(String glyph, TextColor color) {
    }

    record SaveResult(Status status, SavedSpot spot, int index, int capacity) {
        enum Status { CREATED, DUPLICATE, CAPACITY_REACHED }

        static SaveResult created(SavedSpot spot, int index) {
            return new SaveResult(Status.CREATED, spot, index, 0);
        }

        static SaveResult duplicate(SavedSpot spot, int index) {
            return new SaveResult(Status.DUPLICATE, spot, index, 0);
        }

        static SaveResult capacityReached(int capacity) {
            return new SaveResult(Status.CAPACITY_REACHED, null, 0, capacity);
        }
    }

    record DeleteResult(Status status, SavedSpot spot, int size) {
        enum Status { DELETED, INVALID_INDEX }

        static DeleteResult deleted(SavedSpot spot) {
            return new DeleteResult(Status.DELETED, spot, 0);
        }

        static DeleteResult invalid(int size) {
            return new DeleteResult(Status.INVALID_INDEX, null, size);
        }
    }
}
